import requests
import time
import json
from PIL import Image
from io import BytesIO
import torch
import numpy as np

BASE_URL = 'https://api-inference.modelscope.cn/'
API_KEY = "ms-80a31324-cf5a-4a2f-b62b-6716ea19067c"  # ModelScope Token

COMMON_HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
}

class ModelScopeFLUXKontextNode:
    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "prompt": ("STRING", {
                    "multiline": True,
                    "default": "turn the girl's hair blue"
                }),
                "model": ("STRING", {
                    "default": "MusePublic/FLUX.1-Kontext-Dev"
                }),
                "api_key": ("STRING", {
                    "default": "填写你的魔搭社区API-密钥"
                }),
                "image_url": ("STRING", {
                    "default": "https://resources.modelscope.cn/aigc/image_edit.png"
                }),
            },
            "optional": {
                "width": ("INT", {
                    "default": 512,
                    "min": 64,
                    "max": 2048,
                    "step": 64
                }),
                "height": ("INT", {
                    "default": 512,
                    "min": 64,
                    "max": 2048,
                    "step": 64
                }),
                "negative_prompt": ("STRING", {
                    "multiline": True,
                    "default": ""
                }),
                "seed": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 2147483647
                }),
                "steps": ("INT", {
                    "default": 30,
                    "min": 1,
                    "max": 100
                }),
                "guidance": ("FLOAT", {
                    "default": 7.5,
                    "min": 1.5,
                    "max": 20.0,
                    "step": 0.1
                }),
            }
        }

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "generate_image"
    CATEGORY = "modelscope"

    def generate_image(self, prompt, model, api_key, image_url, width=512, height=512, negative_prompt="", seed=-1, steps=30, guidance=7.5):
        headers = {
            **COMMON_HEADERS,
            "Authorization": f"Bearer {api_key}",
            "X-ModelScope-Async-Mode": "true"
        }
        
        # 构建请求参数
        payload = {
            "model": model,
            "prompt": prompt,
            "image_url": image_url,
            "size": f"{width}x{height}",
            "steps": steps,
            "guidance": guidance
        }
        
        # 添加可选参数
        if negative_prompt.strip():
            payload["negative_prompt"] = negative_prompt
        if seed != -1:
            payload["seed"] = seed
        
        response = requests.post(
            f"{BASE_URL}v1/images/generations",
            headers=headers,
            data=json.dumps(payload, ensure_ascii=False).encode('utf-8')
        )
        
        response.raise_for_status()
        task_id = response.json()["task_id"]
        
        while True:
            result = requests.get(
                f"{BASE_URL}v1/tasks/{task_id}",
                headers={
                    **COMMON_HEADERS,
                    "Authorization": f"Bearer {api_key}",
                    "X-ModelScope-Task-Type": "image_generation"
                },
            )
            result.raise_for_status()
            data = result.json()
            
            if data["task_status"] == "SUCCEED":
                image_url = data["output_images"][0]
                image_content = requests.get(image_url).content
                image = Image.open(BytesIO(image_content))
                
                # Convert PIL image to numpy array for ComfyUI
                image_np = np.array(image).astype(np.float32) / 255.0
                image_tensor = torch.from_numpy(image_np)[None,]
                
                return (image_tensor,)
            elif data["task_status"] == "FAILED":
                raise Exception("Image Generation Failed.")
            
            time.sleep(5)

# Register the node
NODE_CLASS_MAPPINGS = {
    "ModelScopeFLUXKontextNode": ModelScopeFLUXKontextNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ModelScopeFLUXKontextNode": "ModelScope FLUX.1-Kontext-Dev"
}