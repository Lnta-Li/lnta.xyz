import requests
import time
import json
from PIL import Image
from io import BytesIO
import torch
import numpy as np

BASE_URL = 'https://api-inference.modelscope.cn/'
API_KEY = "ms-80a31324-cf5a-4a2f-b62b-6716ea19067c"  # ModelScope Token

COMMON_HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
}

class ModelScopeFLUXKreaNode:
    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "prompt": ("STRING", {
                    "multiline": True,
                    "default": "A golden cat"
                }),
                "model": ("STRING", {
                    "default": "black-forest-labs/FLUX.1-Krea-dev"
                }),
                "api_key": ("STRING", {
                    "default": "填写你的魔搭社区API-密钥"
                }),
            },
            "optional": {
                "width": ("INT", {
                    "default": 512,
                    "min": 64,
                    "max": 2048,
                    "step": 64
                }),
                "height": ("INT", {
                    "default": 512,
                    "min": 64,
                    "max": 2048,
                    "step": 64
                }),
                "negative_prompt": ("STRING", {
                    "multiline": True,
                    "default": ""
                }),
                "seed": ("INT", {
                    "default": -1,
                    "min": -1,
                    "max": 2147483647
                }),
                "steps": ("INT", {
                    "default": 30,
                    "min": 1,
                    "max": 100
                }),
                "guidance": ("FLOAT", {
                    "default": 7.5,
                    "min": 1.5,
                    "max": 20.0,
                    "step": 0.1
                }),
            }
        }

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "generate_image"
    CATEGORY = "modelscope"

    def generate_image(self, prompt, model, api_key, width=512, height=512, negative_prompt="", seed=-1, steps=30, guidance=7.5):
        headers = {
            **COMMON_HEADERS,
            "Authorization": f"Bearer {api_key}",
            "X-ModelScope-Async-Mode": "true"
        }
        
        # 构建请求参数
        payload = {
            "model": model,
            "prompt": prompt,
            "size": f"{width}x{height}",
            "steps": steps,
            "guidance": guidance
        }
        
        # 添加可选参数
        if negative_prompt.strip():
            payload["negative_prompt"] = negative_prompt
        if seed != -1:
            payload["seed"] = seed
        
        response = requests.post(
            f"{BASE_URL}v1/images/generations",
            headers=headers,
            data=json.dumps(payload, ensure_ascii=False).encode('utf-8')
        )
        
        # 检查API响应
        if response.status_code != 200:
            raise Exception(f"API request failed with status code {response.status_code}: {response.text}")
        
        try:
            response_data = response.json()
        except json.JSONDecodeError:
            raise Exception(f"Failed to parse API response as JSON: {response.text}")
        
        # 检查响应中是否包含task_id
        if "task_id" not in response_data:
            raise Exception(f"API response doesn't contain task_id. Full response: {response_data}")
            
        task_id = response_data["task_id"]
        
        while True:
            result = requests.get(
                f"{BASE_URL}v1/tasks/{task_id}",
                headers={
                    **COMMON_HEADERS,
                    "Authorization": f"Bearer {api_key}",
                    "X-ModelScope-Task-Type": "image_generation"
                },
            )
            
            # 检查任务状态查询的响应
            if result.status_code != 200:
                raise Exception(f"Task status check failed with status code {result.status_code}: {result.text}")
            
            try:
                data = result.json()
            except json.JSONDecodeError:
                raise Exception(f"Failed to parse task status response as JSON: {result.text}")
            
            # 检查任务状态
            if "task_status" not in data:
                raise Exception(f"Task status response doesn't contain task_status. Full response: {data}")
            
            if data["task_status"] == "SUCCEED":
                # 检查是否包含output_images
                if "output_images" not in data or not data["output_images"]:
                    raise Exception(f"Task succeeded but no output images found. Full response: {data}")
                
                image_url = data["output_images"][0]
                image_content = requests.get(image_url).content
                image = Image.open(BytesIO(image_content))
                
                # Convert PIL image to numpy array for ComfyUI
                image_np = np.array(image).astype(np.float32) / 255.0
                image_tensor = torch.from_numpy(image_np)[None,]
                
                return (image_tensor,)
            elif data["task_status"] == "FAILED":
                # 提供更详细的错误信息
                error_info = data.get("error", "Unknown error") if isinstance(data, dict) else "Unknown error format"
                raise Exception(f"Image Generation Failed: {error_info}. Full response: {data}")
            
            time.sleep(5)

# Register the node
NODE_CLASS_MAPPINGS = {
    "ModelScopeFLUXKreaNode": ModelScopeFLUXKreaNode
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ModelScopeFLUXKreaNode": "ModelScope FLUX.1-Krea-dev (with Size Control)"
}